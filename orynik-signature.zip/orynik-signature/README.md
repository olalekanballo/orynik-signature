# Orynik Signature website

Open `home.html` (or `index.html`) in a browser. For the admin login to work, open the site through
a local server (VS Code "Live Server") or upload it to hosting (https). 

## Admin password
Page: `admin.html` (the "Admin" button at the bottom of the home page).
Password: **Orynik@Glam2026**

To change it, get a SHA-256 hash of your new password (search "SHA-256 generator" or run
`printf 'YourNewPassword' | sha256sum`) and paste it into `adminPasswordHash` in `js/config.js`.
This is a front-end lock only. It keeps casual visitors out but is not real security.

## Important: how bookings reach you
Bookings are saved in the browser where they are made, so the admin page on your phone cannot see a
booking made on a client's phone. Every booking therefore ends with a "Confirm on WhatsApp" button that
sends the full details to 08070929263. To collect bookings from all devices in the admin page, connect a
backend (Firebase, Supabase, Google Sheets) by editing `js/storage.js`, or paste a Formspree URL into
`bookingEndpoint` in `js/config.js` to also receive each booking by email.

## Files to add (the site works without them, using your client photos as stand-ins)
Videos (`assets/video/`): `hero.mp4` (home background), `gallery-1.mp4` to `gallery-4.mp4`, `service-1.mp4` to `service-3.mp4`.
Images (`assets/img/`):
- `tools-1.jpg` to `tools-5.jpg` : home marquee (makeup tools)
- `service-slide-1.jpg` to `service-slide-4.jpg` : services hero slideshow (landscape)
- `service-wedding.jpg`, `service-owambe.jpg`, `service-birthday.jpg`, `service-soft.jpg`, `service-home.jpg`
Use photos you own or royalty-free ones (Unsplash, Pexels). Keep videos under about 8 MB for fast loading.

## Structure
home.html, service.html, about.html, contact.html, faq.html, booknow.html, admin.html
css/style.css (all styling) | js/config.js, main.js, storage.js, booking.js, admin.js
