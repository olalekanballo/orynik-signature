/* Orynik Signature — shared behaviour for every page */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* Sticky header: solid background once the page has scrolled */
  var header = document.getElementById("siteHeader");
  function onScroll() {
    if (header) header.classList.toggle("is-scrolled", window.scrollY > 24);
  }
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* Mobile menu */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("primaryNav");
  function setNav(open) {
    if (!header || !toggle) return;
    header.classList.toggle("nav-open", open);
    toggle.setAttribute("aria-expanded", String(open));
  }
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      setNav(toggle.getAttribute("aria-expanded") !== "true");
    });
    nav.addEventListener("click", function (e) {
      if (e.target.closest("a")) setNav(false);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { setNav(false); toggle.focus(); }
    });
    window.matchMedia("(min-width: 1001px)").addEventListener("change", function () { setNav(false); });
  }

  /* Image fallbacks: if a photo file hasn't been added yet, use the named fallback */
  function applyFallback(img) {
    var fb = img.getAttribute("data-fallback");
    if (!fb || img.getAttribute("data-fallback-used")) return;
    img.setAttribute("data-fallback-used", "1");
    img.src = fb;
  }
  document.querySelectorAll("img[data-fallback]").forEach(function (img) {
    if (img.complete && img.naturalWidth === 0) applyFallback(img);
    img.addEventListener("error", function () { applyFallback(img); });
  });

  /* Marquee: duplicate the set once so the loop is seamless */
  var track = document.querySelector("[data-marquee]");
  if (track && !reduceMotion) {
    Array.prototype.slice.call(track.children).forEach(function (item) {
      var clone = item.cloneNode(true);
      clone.setAttribute("aria-hidden", "true");
      clone.querySelectorAll("img").forEach(function (img) {
        img.alt = "";
        img.addEventListener("error", function () { applyFallback(img); });
      });
      track.appendChild(clone);
    });
  }

  /* Hero slideshow (services page) */
  var slides = document.querySelectorAll(".hero__slide");
  if (slides.length > 1 && !reduceMotion) {
    var current = 0;
    setInterval(function () {
      slides[current].classList.remove("is-active");
      current = (current + 1) % slides.length;
      slides[current].classList.add("is-active");
    }, 5000);
  }

  /* Hero video: respect reduced-motion and save data */
  var heroVideo = document.querySelector(".hero__media[autoplay]");
  if (heroVideo && reduceMotion) { heroVideo.pause(); heroVideo.removeAttribute("autoplay"); }

  /* Only one gallery/reel video plays at a time */
  var videos = document.querySelectorAll("video[data-exclusive]");
  videos.forEach(function (v) {
    v.addEventListener("play", function () {
      videos.forEach(function (other) { if (other !== v) other.pause(); });
    });
  });

  /* Contact page: send the message form to WhatsApp */
  var contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var name = contactForm.elements.name.value.trim();
      var message = contactForm.elements.message.value.trim();
      if (!name || !message) {
        contactForm.querySelector(".form__alert").hidden = false;
        return;
      }
      contactForm.querySelector(".form__alert").hidden = true;
      var text = "Hello Orynik Signature, my name is " + name + ".\n\n" + message;
      window.open(window.ORYNIK.waLink(text), "_blank", "noopener");
    });
  }

  var year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();
})();
